export interface defalutParams {
  code: number;
  data?: any;
}
export interface defalutList {
  age: number;
  id: number;
  name: string;
}
