(()=>{
    interface a {
        a:string,
        n:Boolean
    }

    const b:a = {
        a:"1",
        n:true
    }
})