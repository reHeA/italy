<template>
  <h1>视频页</h1>
  <router-link to="/"> 回主页</router-link>
</template>
<style lang="less" scoped>
h1 {
  width: 750px;
  height: 100px;
  text-align: left;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  background: red;
}
</style>
