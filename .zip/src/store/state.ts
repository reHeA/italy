export default {
  token: '',
  age: 18
};
