const state = {
  // 用户名
  name: ''
};

const mutations = {};

export default {
  namespaced: true,
  state,
  mutations
};
